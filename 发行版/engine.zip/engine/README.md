# 引擎目录

这个目录用于存放中国象棋引擎文件。

## 下载Pikafish引擎

### 方法1：自动下载（推荐）

在项目根目录运行：
```bash
python download_engine.py
```

### 方法2：手动下载

1. 访问 Pikafish 官方发布页面：
   https://github.com/official-pikafish/Pikafish/releases

2. 下载最新版本的Windows版本：
   - 文件名类似：`pikafish-*-windows-x86-64.zip`
   
3. 解压下载的文件

4. 将 `pikafish.exe` 或 `pikafish-windows-x86-64.exe` 复制到这个目录

5. 如果文件名不是 `pikafish.exe`，请重命名为 `pikafish.exe`

## 目录结构

完成配置后，目录应该如下：

```
engine/
├── pikafish.exe        # Pikafish引擎可执行文件（必需）
├── README.md           # 本文件
└── (其他引擎文件)      # 可选的其他引擎
```

## 验证引擎

运行测试脚本验证引擎是否正确配置：

```bash
cd ..
python test_basic.py
```

## 关于Pikafish

**Pikafish** 是目前最强的开源中国象棋引擎之一。

### 特点
- 🧠 基于Stockfish改进，专门优化中国象棋
- 🔥 使用NNUE（高效可更新神经网络）评估局面
- 📊 等级分超过3500
- ⚡ 支持多线程并行计算
- 🔓 开源免费
- 📋 支持标准UCI协议

### 技术细节
- **搜索算法**: Alpha-Beta剪枝，带启发式优化
- **评估**: NNUE神经网络 + 传统评估函数
- **开局库**: 支持外部开局库
- **残局库**: 支持残局表基
- **协议**: UCI (Universal Chess Interface)

### 引擎命令示例

如果你想手动测试引擎，可以在命令行运行：

```bash
engine\pikafish.exe
```

然后输入UCI命令：
```
uci                                    # 初始化
setoption name Hash value 256          # 设置哈希表
ucinewgame                             # 新游戏
position fen <FEN字符串>               # 设置局面
go depth 15                            # 分析15层深度
quit                                   # 退出
```

## 其他引擎

虽然本程序默认使用Pikafish，但也可以配置其他支持UCI协议的中国象棋引擎：

- **ElephantEye** (象眼)
- **XieXie** (谢谢)
- **Cyclone**

配置方法：
1. 下载引擎文件到此目录
2. 在 `chess_assistant.py` 中修改 `engine_path` 变量

## 常见问题

### Q: 引擎文件找不到？
A: 确保文件路径是 `engine/pikafish.exe`，并且文件有执行权限。

### Q: 引擎运行出错？
A: 
- 检查是否下载了正确的Windows x64版本
- 尝试在命令行直接运行引擎查看错误信息
- 确保系统安装了必要的运行库（VC++ Redistributable）

### Q: 如何升级引擎？
A: 下载新版本的引擎文件，替换旧的 `pikafish.exe` 即可。

### Q: 引擎可以商用吗？
A: Pikafish是开源软件（GPL许可），可以免费使用，包括商业用途，但需遵守GPL许可条款。

## 许可

Pikafish引擎本身采用GPL v3许可证。
详见: https://github.com/official-pikafish/Pikafish/blob/master/Copying.txt

## 参考链接

- Pikafish GitHub: https://github.com/official-pikafish/Pikafish
- UCI协议文档: https://www.shredderchess.com/download/div/uci.zip
- 中国象棋FEN格式: https://www.xqbase.com/protocol/cchess_fen.htm

